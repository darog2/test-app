package com.dungeon.task3;

public class Tomato {
}
