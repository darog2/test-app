package com.dungeon.task1;

public class Main1_1 {
    public static void main(String[] args) {
        int dat;
        dat = 35;
        dat = dat + 5;
        dat = dat - 3;
        dat = dat * 4;
        dat = dat / 8;

        dat += 5;
        dat -= 3;
        dat *= 4;
        dat /= 8;

        dat = dat +1;
        dat = dat -1;

        dat++;
        dat--;

        int a = 53;
        int b = 53%5;


    }
}
